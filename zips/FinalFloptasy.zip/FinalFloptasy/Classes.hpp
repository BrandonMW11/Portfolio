//#ifndef Classes_hpp
//#define Classes_hpp

#include <stdio.h>
#pragma once
#include <iostream>
#include <string>

using namespace std;

class combatant{
protected:
	string name;
	int maxHP;
	int currentHP;
	int power;
	int defense;
	int speed;
public:
	combatant(); // I had to add default constructors to combatant, player, and enemy or else errors would occur
	combatant(string name, int maxHP, int currentHP, int power, int defense, int speed);
	string getName();
	int getMaxHP();
	int getCurHP();
	int getPower();
	int getDef();
	int getSpeed();
	void setName(string newName);
	void setMaxHP(int newMaxHP);
	void setCurHP(int newCurHP);
	void setPower(int newPower);
	void setDef(int newDef);
	void setSpeed(int newSpeed);
	virtual void statDisplay(){}
	virtual void commands(){}
};

class player: public combatant{
protected:
	int maxMP;
	int currentMP;
public:
	player();
	player(string name, int maxHP, int currentHP, int power, int defense, int speed, int maxMP, int currentMP): combatant(name, maxHP, currentHP, power, defense, speed)
	{
		this->maxMP=maxMP;
		this->currentMP=currentMP;
	}
	int getMaxMP();
	int getCurMP();
	void setMaxMP(int newMaxMP);
	void setCurMP(int newMaxMP);
	void statDisplay();
	virtual void commands(){}
};

class fighter: public player{
public:
	fighter();
	fighter(string name, int maxHP, int currentHP, int power, int defense, int speed, int maxMP, int currentMP): player(name, maxHP, currentHP, power, defense, speed, maxMP, currentMP){}
	int attackDamage(int isCharged); // "isCharged" will be defined in the main function and will either be one (uncharged) or two (chraged)
	void commands();
};

class cleric: public player{
public:
	cleric();
	cleric(string name, int maxHP, int currentHP, int power, int defense, int speed, int maxMP, int currentMP): player(name, maxHP, currentHP, power, defense, speed, maxMP, currentMP){}
	int attackDamage();
	int hpHealed();
	void commands();
};

class mage: public player{ // The mages normal attack damage will only use their power
public:
	mage();
	mage(string name, int maxHP, int currentHP, int power, int defense, int speed, int maxMP, int currentMP): player(name, maxHP, currentHP, power, defense, speed, maxMP, currentMP){}
	int spellDamage(string enemyType);
	void commands();
};

class enemy: public combatant{ // I was thinking who the enemy target could be determined by a random number in the main cpp file
public:
	enemy();
	enemy(string name, int maxHP, int currentHP, int power, int defense, int speed): combatant(name, maxHP, currentHP, power, defense, speed){}
	void statDisplay();
};

class slime: public enemy{
public:
	slime();
	slime(string name, int maxHP, int currentHP, int power, int defense, int speed): enemy(name, maxHP, currentHP, power, defense, speed){}
};

class goblin: public enemy{
public:
	goblin();
	goblin(string name, int maxHP, int currentHP, int power, int defense, int speed): enemy(name, maxHP, currentHP, power, defense, speed){}
};

class dragon: public enemy{
public:
	dragon();
	dragon(string name, int maxHP, int currentHP, int power, int defense, int speed): enemy(name, maxHP, currentHP, power, defense, speed){}
};
