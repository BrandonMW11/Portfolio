#include <iostream>
#include <string>
#include "Classes.hpp"

using namespace std;

combatant::combatant()
{
	name = "?";
	maxHP = 60;
	currentHP = 60;
	power = 10;
	defense = 7;
	speed = 5;
}

combatant::combatant(string name, int maxHP, int currentHP, int power, int defense, int speed)
{
	this->name=name;
	this->maxHP=maxHP;
	this->currentHP=currentHP;
	this->power=power;
	this->defense=defense;
	this->speed=speed;
}

string combatant::getName()
{
	return name;
}

int combatant::getMaxHP()
{
	return maxHP;
}

int combatant::getCurHP()
{
	return currentHP;
}

int combatant::getPower()
{
	return power;
}

int combatant::getDef()
{
	return defense;
}

int combatant::getSpeed()
{
	return speed;
}

void combatant::setName(string newName)
{
	name = newName;
}

void combatant::setMaxHP(int newMaxHP)
{
	maxHP = newMaxHP;
}

void combatant::setCurHP(int newCurHP)
{
	if(newCurHP <= maxHP) // To prevent characters' HP from exceeding their max
	{
		currentHP = newCurHP;
	}
	else
	{
		currentHP = maxHP;
	}
}

void combatant::setPower(int newPower)
{
	power = newPower;
}

void combatant::setDef(int newDef)
{
	defense = newDef;
}

void combatant::setSpeed(int newSpeed)
{
	speed = newSpeed;
}

player::player()
{
	name = "?";
	maxHP = 60;
	currentHP = 60;
	power = 10;
	defense = 7;
	speed = 5;
	maxMP = 20;
	currentMP = 20;
}

int player::getMaxMP()
{
	return maxMP;
}

int player::getCurMP()
{
	return currentMP;
}

void player::setMaxMP(int newMaxMP)
{
	maxMP = newMaxMP;
}

void player::setCurMP(int newCurMP)
{
	if(newCurMP <= maxMP) // To prevent characters' HP from exceeding their max
	{
		currentMP = newCurMP;
	}
	else
	{
		currentMP = maxMP;
	}
}

void player::statDisplay()
{
	cout << name << ": HP:" << currentHP << "/" << maxHP << " MP:" << currentMP << "/" << maxMP << endl;
}

fighter::fighter()
{
	name = "Fighter";
	maxHP = 60;
	currentHP = 60;
	power = 12;
	defense = 7;
	speed = 5;
	maxMP = 20;
	currentMP = 20;
}

void fighter::commands()
{
	cout << "What will " << name << " do?" << endl << "1) Attack" << endl << "2) Charge (-5 MP)" << endl << "3) Focus (+5 MP)" << endl; 
}

int fighter::attackDamage(int isCharged)
{
	return power * isCharged;
}

cleric::cleric()
{
	name = "Cleric";
	maxHP = 40;
	currentHP = 40;
	power = 15;
	defense = 4;
	speed = 3;
	maxMP = 50;
	currentMP = 50;
}

int cleric::attackDamage()
{
	return power - 7;
}

int cleric::hpHealed()
{
	return power + 10;
}

void cleric::commands()
{
	cout << "What will " << name << " do?" << endl << "1) Attack" << endl << "2) Heal (-4 MP)" << endl << "3) Focus (+5 MP)" << endl; 
}

mage::mage()
{
	name = "Mage";
	maxHP = 50;
	currentHP = 50;
	power = 10;
	defense = 5;
	speed = 8;
	maxMP = 40;
	currentMP = 40;
}

int mage::spellDamage(string enemyType)
{
	if(enemyType == "Slime")
	{
		return power + 10;
	}
	else if (enemyType == "Goblin")
	{
		return power + 6;
	}
	else if (enemyType == "Dragon")
	{
		return power + 15;
	}
	// Had to add this else to prevent an error
	return power;
}

void mage::commands()
{
	cout << "What will " << name << " do?" << endl << "1) Attack" << endl << "2) Cast (-6 MP)" << endl << "3) Focus (+5 MP)" << endl; 
}

enemy::enemy()
{
	name = "?";
	maxHP = 60;
	currentHP = 60;
	power = 10;
	defense = 7;
	speed = 5;
}

void enemy::statDisplay()
{
	cout << name << ": HP:" << currentHP << "/" << maxHP << endl;
}

slime::slime()
{
	name = "Slime";
	maxHP = 50;
	currentHP = 50;
	power = 8;
	defense = 4;
	speed = 4;
}

goblin::goblin()
{
	name = "Goblin";
	maxHP = 75;
	currentHP = 75;
	power = 12;
	defense = 6;
	speed = 6;
}

dragon::dragon()
{
	name = "Dragon";
	maxHP = 100;
	currentHP = 100;
	power = 18;
	defense = 8;
	speed = 1;
}
