#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include "Classes.cpp"
// I know there's some hardcoding in here but we'll change that when the time comes
using namespace std;
// This is how enemies choose who to target
int chooseTarget(int partyAlive)
{
	int target;
	srand(time(0));
	target = (rand() % partyAlive);
	return target;
}

int main()
{
	string characterName, enemyName;
	bool monsterAlive = true;
	bool valid = false;
	int speed1, speed2, target, damage, enemyPos, mpChange, targetsHP;
	int playerChoice = 0;
	int charge = 1;
	int partyAlive = 3;
	// We'll use default constructors to save us the hassle of remebering all the stats
	combatant** battle = new combatant*[4]{
		new fighter(),
		new cleric(),
		new mage(),
		new slime()
	};
	
	for(int i = 0; i < 3; i++)
	{
		cout << "Enter the name of your " << battle[i]->getName() << ": ";
		getline(cin, characterName);
		battle[i]->setName(characterName);
	}
	// This for loop reorders the combatants from highest to lowest speed
	// It's placed here to make the naming process easier
	for(int a = 0; a < 4; a++)
    {
        speed1 = battle[a]->getSpeed();
        for(int b = a + 1; b < 4; b++)
        {
            speed2 = battle[b]->getSpeed();
            if(speed1 < speed2)
            {
                swap(battle[a], battle[b]);
            }
            else if(speed1 == speed2)
            {
				// In the event of a speed tie, party members will go before enemies
                if(enemy * e = dynamic_cast<enemy *>(battle[a]))
				{
					swap(battle[a], battle[b]);
				}
            }
            speed1 = battle[a]->getSpeed();
            speed2 = battle[b]->getSpeed();
        }
    }
    // This for loop locates the enemies position in the array which makes coding the battles easier
    for(int i = 0; i < 4; i++)
    {
		if(enemy * e = dynamic_cast<enemy *>(battle[i]))
		{
			enemyPos = i;
			break;
		}
	}
	// This while loop keeps the battle going until either the party or monster dies
	// How damage will work is that it takes the power of the attacker (or if there is a special damage formula that gets used) and subtract it by the defense of the one being attacked
	while(monsterAlive == true && partyAlive > 0)
	{
		for(int i = 0; i < 4; i++)
		{
			cout << "-----------------------------------" << endl;
			for(int j = 0; j < 4; j++)
			{
				battle[j]->statDisplay();
			}
			cout << "-----------------------------------" << endl;
			if(enemyPos == i)
			{
				target = chooseTarget(partyAlive);
				for(int j = 0; j < 4; j++)
				{
					if(j == target)
					{
						if(enemy * e = dynamic_cast<enemy *>(battle[j])) // This is so enemies only attack alive players
						{
							target++;
						}
						else if(battle[j]->getCurHP() <= 0)
						{
							target++;
						}
						else
						{
							damage = battle[i]->getPower()  - battle[j]->getDef();
							targetsHP = battle[j]->getCurHP() - damage;
							battle[j]->setCurHP(targetsHP);
							cout << "The " << battle[i]->getName() << " did " << damage << " damage to " << battle[j]->getName() << "." << endl;
							if(battle[j]->getCurHP() <= 0)
							{
								cout << battle[j]->getName() << " died." << endl;
								partyAlive--;
							}
							break;
						}
					}
				}
			}
			else
			{
				if(player * p = dynamic_cast<player *>(battle[i]))
				{
					if(battle[i]->getCurHP() > 0)
					{
						while(playerChoice < 1 || playerChoice > 3)
						{
							p->commands();
							cout << ">> ";
							cin >> playerChoice;
							switch(playerChoice)
							{
								case 1:
									if(fighter * f = dynamic_cast<fighter *>(battle[i]))
									{
										damage = f->attackDamage(charge) - battle[enemyPos]->getDef();
										charge = 1;
									}
									else if(cleric * c = dynamic_cast<cleric *>(battle[i]))
									{
										damage = c->attackDamage() - battle[enemyPos]->getDef();
									}
									else
									{
										damage = p->getPower() - battle[enemyPos]->getDef();
									}
									if(damage < 0)
									{
										damage = 0;
									}
									targetsHP = battle[enemyPos]->getCurHP() - damage;
									battle[enemyPos]->setCurHP(targetsHP);
									cout << p->getName() << " did " << damage << " damage to the " << battle[enemyPos]->getName() << "." << endl;
									break;
								case 2:
									if(fighter * f = dynamic_cast<fighter *>(battle[i]))
									{
										if(f->getCurMP() >= 5 && charge == 1)
										{
											charge = 2;
											mpChange = f->getCurMP() - 5;
											f->setCurMP(mpChange);
											cout << f->getName() << " spent 5 MP charging their next attack." << endl;
										}
										else if(charge != 1)
										{
											cout << f->getName() << " is already charged." << endl;
											playerChoice = 0;
										}
										else
										{
											cout << f->getName() << " does not have enough MP to charge." << endl;
											playerChoice = 0;
										}
									}
									else if(cleric * c = dynamic_cast<cleric *>(battle[i]))
									{
										if(c->getCurMP() >= 4)
										{
											while(valid == false)
											{
												cout << "Who will " << c->getName() << " heal?" << endl << ">> ";
												// I just didn't want to make another variable [we should probably make another variable so that it's legible --Z]
												// Adding cin.ignore() created an issue where entering the name of a comabatant that doesn't exist causes futrue input readings to exclude the first letter. Try it out for yourself and you'll see what I mean.
												// ^ You don't need cin.ignore after getline.  Is that what you were trying to do?  Besides, I think getline works better for a name anyway.
												getline(cin, enemyName);
												for(int j = 0; j < 4; j++)
												{
													if(enemyName == battle[j]->getName())
													{
														if(battle[j]->getCurHP() > 0)
														{
															mpChange = c->getCurMP() - 4;
															c->setCurMP(mpChange);
															targetsHP = battle[j]->getCurHP() + c->hpHealed();
															battle[j]->setCurHP(targetsHP);
															cout << c->getName() << " spent 4 MP healing " << enemyName << ".";
															valid = true;
															break;
														}
														else
														{
															cout << enemyName << " is dead." << endl;
															break;
														}
													}
													if(j == 3)
													{
														cout << "There is no combatant named " << enemyName << "." << endl;
													}
												}
											}
											valid = false;
										}
										else
										{
											cout << c->getName() << " does not have enough MP to heal." << endl;
											playerChoice = 0;
										}
									}
									else if(mage * m = dynamic_cast<mage *>(battle[i]))
									{
										if(m->getCurMP() >= 6)
										{
											mpChange = m->getCurMP() - 6;
											m->setCurMP(mpChange);
											enemyName = battle[enemyPos]->getName();
											damage = m->spellDamage(enemyName)  - battle[enemyPos]->getDef();
											targetsHP = battle[enemyPos]->getCurHP() - damage;
											battle[enemyPos]->setCurHP(targetsHP);
											cout << m->getName() << " spent 6 MP casting a spell." << endl << m->getName() << "'s spell did " << damage << " damage to the " << battle[enemyPos]->getName() << "." << endl;
										}
										else
										{
											cout << m->getName() << " does not have enough MP to cast." << endl;
											playerChoice = 0;
										}
									}
									break;
								case 3:
									mpChange = p->getCurMP() + 5;
									p->setCurMP(mpChange);
									cout << p->getName() << " recovered 5 MP." << endl;
									break;
								default:
									cout << "Invalid input!" << endl;
							}
							cout << endl;
						}
					}
					playerChoice = 0;
				}
			}
			if(battle[enemyPos]->getCurHP() <= 0)
			{
				cout << "The " << battle[enemyPos]->getName() << " has been defeated." << endl;
				monsterAlive = false;
				break;
			}
		}
	}
	
	if(partyAlive == 0)
	{
		cout << endl << "You failed." << endl;
	}
	else
	{
		cout << endl << "You won." << endl;
	}
	
	// We need to use a variable to keep track of array size.
	for(int i = 0; i < 4; i++)
	{
		delete battle[i];
	}
	delete [] battle;
	return 0;
}
